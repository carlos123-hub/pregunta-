package pe.edu.upeu.conceptos_poo.minimarket.Controladores;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.minimarket.components.ColumnInfo;
import pe.edu.upeu.conceptos_poo.minimarket.components.TableViewHelper;
import pe.edu.upeu.conceptos_poo.minimarket.components.ValidationTooltip;
import pe.edu.upeu.conceptos_poo.minimarket.enums.TipoDocumento;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Cliente;
import pe.edu.upeu.conceptos_poo.minimarket.service.ClienteService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class GestionClientesController {

    @FXML private TextField txtFiltroClientes;
    @FXML private TableView<Cliente> tableViewClientes;
    @FXML private TextField txtDniRuc, txtNombres, txtDireccion, txtEmail;
    @FXML private ComboBox<TipoDocumento> cbTipoDocumento;
    @FXML private Button btnGuardarCliente;
    @FXML private Label lblMensajeCliente;

    @Autowired private ClienteService clienteService;

    private ObservableList<Cliente> listaClientesObservable;
    private String idClienteEditando = null;

    @FXML
    public void initialize() {
        cbTipoDocumento.setItems(FXCollections.observableArrayList(TipoDocumento.values()));
        configurarTablaClientes();
        listarClientes();
        txtFiltroClientes.textProperty().addListener((obs, oldVal, newVal) -> filtrarClientes(newVal));
        txtDniRuc.textProperty().addListener((obs, oldVal, newVal) ->
                marcarError(txtDniRuc, newVal.trim().isEmpty(), "Ingrese el DNI o RUC"));
        txtNombres.textProperty().addListener((obs, oldVal, newVal) ->
                marcarError(txtNombres, newVal.trim().isEmpty(), "Ingrese los nombres del cliente"));
        txtDireccion.textProperty().addListener((obs, oldVal, newVal) ->
                marcarError(txtDireccion, newVal.trim().isEmpty(), "Ingrese la dirección del cliente"));
        txtEmail.textProperty().addListener((obs, oldVal, newVal) ->
                marcarError(txtEmail, !correoValido(newVal.trim()), "Ingrese un correo válido"));
        cbTipoDocumento.valueProperty().addListener((obs, oldVal, newVal) ->
                marcarError(cbTipoDocumento, newVal == null, "Seleccione el tipo de documento"));
        cancelarEdicionCliente();
    }

    private void configurarTablaClientes() {
        TableViewHelper<Cliente> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columnas = new LinkedHashMap<>();
        columnas.put("DNI/RUC", new ColumnInfo("dniruc", 100.0));
        columnas.put("Nombres", new ColumnInfo("nombres", 200.0));
        columnas.put("Tipo Doc.", new ColumnInfo("tipoDocumento", 80.0));
        columnas.put("Email", new ColumnInfo("email", 150.0)); // Nuevo campo
        columnas.put("Dirección", new ColumnInfo("direccion", 150.0));

        helper.addColumnsInOrderWithSize(tableViewClientes, columnas, this::editarCliente, this::eliminarCliente);
    }

    private void listarClientes() {
        try {
            listaClientesObservable = FXCollections.observableArrayList(clienteService.findAll());
            tableViewClientes.setItems(listaClientesObservable);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void filtrarClientes(String filtro) {
        if (filtro == null || filtro.isEmpty()) {
            tableViewClientes.setItems(listaClientesObservable);
        } else {
            String lower = filtro.toLowerCase();
            List<Cliente> filtrados = listaClientesObservable.stream()
                    .filter(c -> c.getDniruc().toLowerCase().contains(lower) || c.getNombres().toLowerCase().contains(lower))
                    .collect(Collectors.toList());
            tableViewClientes.setItems(FXCollections.observableArrayList(filtrados));
        }
    }

    @FXML
    private void guardarCliente() {
        String dni = txtDniRuc.getText().trim();
        String nom = txtNombres.getText().trim();
        String direccion = txtDireccion.getText().trim();
        String email = txtEmail.getText().trim();
        TipoDocumento tipo = cbTipoDocumento.getValue();

        limpiarEstilosError();
        boolean dniVacio = dni.isEmpty();
        boolean nombreVacio = nom.isEmpty();
        boolean direccionVacia = direccion.isEmpty();
        boolean correoInvalido = !correoValido(email);
        boolean tipoVacio = tipo == null;
        marcarError(txtDniRuc, dniVacio, "Ingrese el DNI o RUC");
        marcarError(txtNombres, nombreVacio, "Ingrese los nombres del cliente");
        marcarError(txtDireccion, direccionVacia, "Ingrese la dirección del cliente");
        marcarError(txtEmail, correoInvalido, "Ingrese un correo válido");
        marcarError(cbTipoDocumento, tipoVacio, "Seleccione el tipo de documento");

        if (dniVacio || nombreVacio || direccionVacia || correoInvalido || tipoVacio) {
            StringBuilder campos = new StringBuilder();
            agregarCampoFaltante(campos, dniVacio, "DNI/RUC");
            agregarCampoFaltante(campos, nombreVacio, "nombres");
            agregarCampoFaltante(campos, direccionVacia, "dirección");
            agregarCampoFaltante(campos, correoInvalido, "correo válido");
            agregarCampoFaltante(campos, tipoVacio, "tipo de documento");
            mostrarMensajeCliente("Complete los campos obligatorios: " + campos + ".", true);
            enfocarPrimerCampoInvalido(dniVacio, nombreVacio, direccionVacia, correoInvalido, tipoVacio);
            return;
        }

        try {
            Cliente c = (idClienteEditando != null) ? clienteService.findById(idClienteEditando) : new Cliente();

            if (idClienteEditando == null && clienteService.existsById(dni)) {
                mostrarMensajeCliente("Cliente ya existe.", true);
                return;
            }

            c.setDniruc(dni);
            c.setNombres(nom);
            c.setDireccion(direccion);
            c.setEmail(email);
            c.setTipoDocumento(tipo);

            clienteService.save(c);
            mostrarMensajeCliente("Guardado exitosamente.", false);
            cancelarEdicionCliente();
            listarClientes();
        } catch (Exception e) {
            mostrarMensajeCliente("Error: " + e.getMessage(), true);
        }
    }

    private void editarCliente(Cliente c) {
        idClienteEditando = c.getDniruc();
        txtDniRuc.setText(c.getDniruc());
        txtDniRuc.setDisable(true);
        txtNombres.setText(c.getNombres());
        txtDireccion.setText(c.getDireccion());
        txtEmail.setText(c.getEmail());
        cbTipoDocumento.setValue(c.getTipoDocumento());
        btnGuardarCliente.setText("Actualizar");
    }

    private void eliminarCliente(Cliente c) {
        clienteService.delete(c.getDniruc());
        listarClientes();
    }

    @FXML
    private void cancelarEdicionCliente() {
        idClienteEditando = null;
        txtDniRuc.clear();
        txtDniRuc.setDisable(false);
        txtNombres.clear();
        txtDireccion.clear();
        txtEmail.clear();
        cbTipoDocumento.setValue(null);
        btnGuardarCliente.setText("Guardar");
        lblMensajeCliente.setText("");
        limpiarEstilosError();
    }

    private void mostrarMensajeCliente(String msg, boolean error) {
        lblMensajeCliente.setText(msg);
        lblMensajeCliente.setStyle(error ? "-fx-text-fill: red;" : "-fx-text-fill: green;");
    }

    private void agregarCampoFaltante(StringBuilder campos, boolean faltante, String nombre) {
        if (!faltante) return;
        if (campos.length() > 0) campos.append(", ");
        campos.append(nombre);
    }

    private void enfocarPrimerCampoInvalido(boolean dniVacio, boolean nombreVacio,
                                            boolean direccionVacia, boolean correoInvalido,
                                            boolean tipoVacio) {
        Control primerInvalido = null;
        if (dniVacio) primerInvalido = txtDniRuc;
        else if (nombreVacio) primerInvalido = txtNombres;
        else if (direccionVacia) primerInvalido = txtDireccion;
        else if (correoInvalido) primerInvalido = txtEmail;
        else if (tipoVacio) primerInvalido = cbTipoDocumento;

        if (primerInvalido != null) {
            primerInvalido.requestFocus();
            ValidationTooltip.mostrar(primerInvalido);
        }
    }

    private boolean correoValido(String correo) {
        return correo != null && correo.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }

    private void marcarError(Control control, boolean error, String mensaje) {
        ValidationTooltip.marcar(control, error, mensaje);
    }

    private void limpiarEstilosError() {
        marcarError(txtDniRuc, false, "");
        marcarError(txtNombres, false, "");
        marcarError(txtDireccion, false, "");
        marcarError(txtEmail, false, "");
        marcarError(cbTipoDocumento, false, "");
    }
}
