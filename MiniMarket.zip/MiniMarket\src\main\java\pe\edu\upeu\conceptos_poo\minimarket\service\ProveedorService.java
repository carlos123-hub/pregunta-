package pe.edu.upeu.conceptos_poo.minimarket.service;

import pe.edu.upeu.conceptos_poo.minimarket.modelos.Proveedor;

public interface ProveedorService extends CRUD_GenericoSefvice_Interface<Proveedor, Long> {
}