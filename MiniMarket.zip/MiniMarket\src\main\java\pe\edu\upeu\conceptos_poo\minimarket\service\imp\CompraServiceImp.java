package pe.edu.upeu.conceptos_poo.minimarket.service.imp;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Compra;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.DetalleCompra;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Producto;
import pe.edu.upeu.conceptos_poo.minimarket.repository.ICompraRepository;
import pe.edu.upeu.conceptos_poo.minimarket.repository.ICrudGenericoRepository;
import pe.edu.upeu.conceptos_poo.minimarket.service.CompraService;
import pe.edu.upeu.conceptos_poo.minimarket.service.ProductoIService;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class CompraServiceImp extends CRUD_GenericoServiceImp<Compra, Long> implements CompraService {

    private final ICompraRepository compraRepository;
    private final ProductoIService productoService;

    @Override
    protected ICrudGenericoRepository<Compra, Long> getRepository() {
        return compraRepository;
    }

    @Override
    public Compra registrarCompra(Compra compra) {
        Compra compraGuardada = compraRepository.save(compra);

        List<DetalleCompra> detalles = compra.getDetalleCompras();
        if (detalles != null) {
            for (DetalleCompra detalle : detalles) {
                detalle.setCompra(compraGuardada);

                // Actualizar Stock
                Producto producto = productoService.findProductoById(detalle.getProducto().getId_producto());
                if (producto != null) {
                    long nuevoStock = producto.getStok() + detalle.getCantidad();
                    producto.setStok(nuevoStock);
                    productoService.updateProducto(producto);
                }
            }
        }
        return compraGuardada;
    }

    @Override
    public List<Compra> findComprasBetweenFechas(LocalDateTime inicio, LocalDateTime fin) {
        return compraRepository.findComprasByFechaEmisionBetween(inicio, fin);
    }
}