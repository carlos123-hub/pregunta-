@echo off
setlocal
cd /d "%~dp0"

set "JAVA_EXE=java"
if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
) else (
    if exist "C:\Program Files\Java\jdk-24\bin\java.exe" set "JAVA_HOME=C:\Program Files\Java\jdk-24"
    if exist "C:\Program Files\Java\latest\bin\java.exe" set "JAVA_HOME=C:\Program Files\Java\latest"
    if defined JAVA_HOME set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
)

echo Actualizando MiniMarket...
call mvnw.cmd -q -DskipTests compile dependency:copy-dependencies
if errorlevel 1 (
    echo.
    echo No se pudo actualizar el proyecto. Revisa que JAVA_HOME apunte a un JDK instalado.
    pause
    exit /b 1
)

"%JAVA_EXE%" --module-path "target\dependency" --add-modules javafx.controls,javafx.fxml,javafx.swing -cp "target\classes;target\dependency\*" pe.edu.upeu.conceptos_poo.minimarket.MiniMarketApplication

if errorlevel 1 (
    echo.
    echo La aplicacion no pudo iniciar.
    pause
)
