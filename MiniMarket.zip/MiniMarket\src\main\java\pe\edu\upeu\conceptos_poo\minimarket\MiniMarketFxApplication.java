package pe.edu.upeu.conceptos_poo.minimarket;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import pe.edu.upeu.conceptos_poo.minimarket.components.StageManager;

/** Ciclo de vida JavaFX separado del punto de entrada ejecutable. */
public class MiniMarketFxApplication extends Application {
    private ConfigurableApplicationContext applicationContext;
    private Parent root;

    @Override
    public void init() throws Exception {
        applicationContext = new SpringApplicationBuilder(MiniMarketApplication.class)
                .web(WebApplicationType.NONE)
                .run(getParameters().getRaw().toArray(new String[0]));

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/PrimeraCapa.fxml"));
        loader.setControllerFactory(applicationContext::getBean);
        root = loader.load();
    }

    @Override
    public void start(Stage stage) {
        StageManager.setPrimaryStage(stage);
        stage.setScene(new Scene(root));
        stage.setTitle("MiniMarket - Sistema de Ventas");
        stage.show();
    }

    @Override
    public void stop() {
        if (applicationContext != null) {
            applicationContext.close();
        }
    }
}
