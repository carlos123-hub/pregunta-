package pe.edu.upeu.conceptos_poo.minimarket.Controladores;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.minimarket.enums.TipoDocumento;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Cliente;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.DetalleVenta;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Producto;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Venta;
import pe.edu.upeu.conceptos_poo.minimarket.service.ClienteService;
import pe.edu.upeu.conceptos_poo.minimarket.service.EmailService;
import pe.edu.upeu.conceptos_poo.minimarket.service.ProductoIService;
import pe.edu.upeu.conceptos_poo.minimarket.service.ReportService;
import pe.edu.upeu.conceptos_poo.minimarket.service.VentaService;
import pe.edu.upeu.conceptos_poo.minimarket.utils.PrinterUtil;

import javax.print.PrintException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class ClienteMainController {

    @Autowired private ProductoIService productoService;
    @Autowired private VentaService ventaService;
    @Autowired private ClienteService clienteService;
    @Autowired private ReportService reportService;
    @Autowired private EmailService emailService;
    @Autowired private ConfigurableApplicationContext applicationContext;

    private ObservableList<Producto> listaProductosObs;
    private ObservableList<ProductoVenta> listaCarritoObs = FXCollections.observableArrayList();

    @FXML private TextField txtFiltroProductos;
    @FXML private TableView<Producto> tableViewProductos;
    @FXML private TableColumn<Producto, String> colProdNombre, colProdCategoria;
    @FXML private TableColumn<Producto, Double> colProdPrecio;
    @FXML private TableColumn<Producto, Long> colProdStock;
    @FXML private TableColumn<Producto, Void> colProdAccion;

    @FXML private TableView<ProductoVenta> tableViewCarrito;
    @FXML private TableColumn<ProductoVenta, String> colCartNombre;
    @FXML private TableColumn<ProductoVenta, Integer> colCartCantidad;
    @FXML private TableColumn<ProductoVenta, Double> colCartPrecio, colCartSubtotal;
    @FXML private TableColumn<ProductoVenta, Void> colCartAccion;

    @FXML private Label lblTotal;
    @FXML private Button btnPagar;

    private static final double TASA_IGV = 0.18;

    @FXML
    public void initialize() {
        configurarTablaProductos();
        configurarTablaCarrito();
        cargarProductos();
        txtFiltroProductos.textProperty().addListener((obs, oldVal, newVal) -> filtrarProductos(newVal));
        tableViewCarrito.setItems(listaCarritoObs);
        btnPagar.setText("R. Venta");
    }

    private void configurarTablaProductos() {
        colProdNombre.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNombre()));
        colProdCategoria.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getCategoria().getNombre()));
        colProdPrecio.setCellValueFactory(new PropertyValueFactory<>("PrecioU"));
        colProdStock.setCellValueFactory(new PropertyValueFactory<>("stok"));
        colProdAccion.setCellFactory(param -> new TableCell<>() {
            private final Button btnAnadir = new Button("Añadir");
            {
                btnAnadir.setStyle("-fx-background-color: #28a745; -fx-text-fill: white;");
                btnAnadir.setOnAction(event -> {
                    Producto p = getTableView().getItems().get(getIndex());
                    if (p.getStok() > 0) agregarAlCarrito(p);
                    else mostrarAlerta("Stock Agotado", "No hay stock disponible.", Alert.AlertType.WARNING);
                });
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : btnAnadir);
            }
        });
    }

    private void configurarTablaCarrito() {
        colCartNombre.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getProducto().getNombre()));
        colCartCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        colCartPrecio.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getProducto().getPrecioU()).asObject());
        colCartSubtotal.setCellValueFactory(new PropertyValueFactory<>("subtotal"));
        colCartAccion.setCellFactory(param -> new TableCell<>() {
            private final Button btnQuitar = new Button("Quitar");
            {
                btnQuitar.setStyle("-fx-background-color: #dc3545; -fx-text-fill: white; -fx-font-size: 10px;");
                btnQuitar.setOnAction(event -> {
                    listaCarritoObs.remove(getIndex());
                    actualizarTotal();
                    tableViewCarrito.refresh();
                });
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : btnQuitar);
            }
        });
    }

    private void cargarProductos() {
        listaProductosObs = FXCollections.observableArrayList(productoService.findAllProductos());
        tableViewProductos.setItems(listaProductosObs);
    }

    private void filtrarProductos(String filtro) {
        if (filtro == null || filtro.isEmpty()) tableViewProductos.setItems(listaProductosObs);
        else {
            String lower = filtro.toLowerCase();
            List<Producto> filtrados = listaProductosObs.stream()
                    .filter(p -> p.getNombre().toLowerCase().contains(lower) || p.getCategoria().getNombre().toLowerCase().contains(lower))
                    .collect(Collectors.toList());
            tableViewProductos.setItems(FXCollections.observableArrayList(filtrados));
        }
    }

    private void agregarAlCarrito(Producto producto) {
        TextInputDialog dialog = new TextInputDialog("1");
        dialog.setTitle("Anadir al Carrito");
        dialog.setHeaderText("Anadiendo: " + producto.getNombre());
        dialog.setContentText("Cantidad:");
        Optional<String> result = dialog.showAndWait();
        if (result.isPresent()) {
            try {
                int cantidad = Integer.parseInt(result.get());
                if (cantidad <= 0) {
                    mostrarAlerta("Error", "La cantidad debe ser positiva.", Alert.AlertType.ERROR);
                    return;
                }
                if (cantidad > producto.getStok()) {
                    mostrarAlerta("Error", "Stock insuficiente. Disponible: " + producto.getStok(), Alert.AlertType.ERROR);
                    return;
                }

                Optional<ProductoVenta> existente = listaCarritoObs.stream()
                        .filter(pv -> pv.getProducto().getId_producto().equals(producto.getId_producto()))
                        .findFirst();
                if (existente.isPresent()) {
                    int nuevaCant = existente.get().getCantidad() + cantidad;
                    if (nuevaCant > producto.getStok()) {
                        mostrarAlerta("Error", "Stock insuficiente para el total acumulado.", Alert.AlertType.ERROR);
                        return;
                    }
                    existente.get().setCantidad(nuevaCant);
                }
                else listaCarritoObs.add(new ProductoVenta(producto, cantidad));
                tableViewCarrito.refresh();
                actualizarTotal();
            } catch (NumberFormatException e) { mostrarAlerta("Error", "Número inválido.", Alert.AlertType.ERROR); }
        }
    }

    private void actualizarTotal() {
        double total = listaCarritoObs.stream().mapToDouble(ProductoVenta::getSubtotal).sum();
        lblTotal.setText(String.format("%.2f", total));
    }

    @FXML
    private void pagar() {
        if (listaCarritoObs.isEmpty()) {
            mostrarAlerta("Carrito Vacío", "Agregue productos antes de pagar.", Alert.AlertType.WARNING);
            return;
        }

        try {
            Cliente cliente = pedirDatosClienteLocal();
            if (cliente == null) return; // Cancelado por el usuario

            Venta venta = new Venta();
            venta.setCliente(cliente);
            venta.setFechaGeneracion(LocalDateTime.now());

            double total = Double.parseDouble(lblTotal.getText().replace(",", "."));
            venta.setTotal(total);
            venta.setSubtotal(total / (1 + TASA_IGV));
            venta.setIgv(total - venta.getSubtotal());

            // Determinar Serie y Tipo
            venta.setTipoDocumento(cliente.getTipoDocumento() == TipoDocumento.RUC ? "FACTURA" : "BOLETA");
            venta.setSerie(cliente.getTipoDocumento() == TipoDocumento.RUC ? "F001" : "B001");

            List<DetalleVenta> detalles = new ArrayList<>();
            for (ProductoVenta pv : listaCarritoObs) {
                DetalleVenta d = new DetalleVenta();
                d.setProducto(pv.getProducto());
                d.setCantidad(pv.getCantidad());
                d.setPrecioUnitario(pv.getProducto().getPrecioU());
                d.setSubtotalProducto(pv.getSubtotal());
                d.setVenta(venta);
                detalles.add(d);
            }
            venta.setDetalleVentas(detalles);

            // Guardar Venta
            Venta ventaGuardada = ventaService.registrarVentaCompleta(venta);

            // --- MOSTRAR VENTANA DE OPCIONES (Imprimir / Email) ---
            String textoTicket = generarTextoRecibo(ventaGuardada);
            mostrarOpcionesPostVenta(ventaGuardada, textoTicket);

            // Limpiar
            listaCarritoObs.clear();
            actualizarTotal();
            cargarProductos();

        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Error", "No se pudo procesar la venta: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private Cliente pedirDatosClienteLocal() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/buscar_cliente_dialog.fxml"));
        loader.setControllerFactory(applicationContext::getBean);
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.initModality(Modality.WINDOW_MODAL);
        stage.setScene(new Scene(root));
        BuscarClienteDialogController controller = loader.getController();
        controller.setDialogStage(stage);
        stage.showAndWait();
        return controller.getClienteSeleccionado();
    }

    /**
     * Muestra un diálogo con el texto del ticket y botones MANUALES para Imprimir o Enviar Email.
     */
    private void mostrarOpcionesPostVenta(Venta venta, String textoRecibo) {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Venta Completada - " + venta.getTipoDocumento());
        dialog.setHeaderText("Venta registrada correctamente.\nSeleccione una acción:");

        // Área de texto con el recibo
        TextArea textArea = new TextArea(textoRecibo);
        textArea.setEditable(false);
        textArea.setWrapText(true);
        textArea.setFont(new javafx.scene.text.Font("Monospaced", 12));
        textArea.setPrefHeight(300);
        textArea.setPrefWidth(400);

        // Botones
        Button btnImprimir = new Button("Imprimir Ticket");
        btnImprimir.setStyle("-fx-background-color: #007bff; -fx-text-fill: white; -fx-font-weight: bold;");
        btnImprimir.setOnAction(e -> manejarImpresion(textoRecibo));

        Button btnEmail = new Button("Enviar PDF por Email");
        btnEmail.setStyle("-fx-background-color: #17a2b8; -fx-text-fill: white; -fx-font-weight: bold;");
        btnEmail.setOnAction(e -> manejarEnvioEmail(venta));

        // Contenedor de botones
        HBox buttonBox = new HBox(10, btnImprimir, btnEmail);
        buttonBox.setAlignment(javafx.geometry.Pos.CENTER);

        // Layout principal
        VBox content = new VBox(10, textArea, buttonBox);
        content.setPadding(new javafx.geometry.Insets(10));

        dialog.getDialogPane().setContent(content);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);

        dialog.showAndWait();
    }

    private void manejarImpresion(String textoRecibo) {
        try {
            List<String> impresoras = PrinterUtil.getImpresoras();
            if (impresoras.isEmpty()) {
                mostrarAlerta("Error de Impresión", "No se detectaron impresoras.", Alert.AlertType.WARNING);
                return;
            }

            ChoiceDialog<String> printerDialog = new ChoiceDialog<>(impresoras.get(0), impresoras);
            printerDialog.setTitle("Seleccionar Impresora");
            printerDialog.setHeaderText("Elija la impresora para el ticket:");
            printerDialog.setContentText("Impresora:");

            Optional<String> result = printerDialog.showAndWait();
            if (result.isPresent()) {
                PrinterUtil.imprimirTexto(textoRecibo, result.get());
                mostrarAlerta("Éxito", "Ticket enviado a la impresora.", Alert.AlertType.INFORMATION);
            }
        } catch (PrintException ex) {
            mostrarAlerta("Error de Impresión", ex.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void manejarEnvioEmail(Venta venta) {
        Cliente c = venta.getCliente();
        if (c.getEmail() == null || c.getEmail().isEmpty()) {
            TextInputDialog emailDialog = new TextInputDialog();
            emailDialog.setTitle("Email Faltante");
            emailDialog.setHeaderText("El cliente no tiene email registrado.");
            emailDialog.setContentText("Ingrese el email:");
            Optional<String> res = emailDialog.showAndWait();
            if (res.isPresent() && !res.get().isEmpty()) {
                c.setEmail(res.get());
                // Opcional: actualizar cliente en BD
                // clienteService.save(c);
            } else {
                return;
            }
        }

        try {
            // Generar PDF
            byte[] pdfBytes = reportService.generarBoletaPdf(venta.getIdVenta());

            // Enviar
            String asunto = "Comprobante MiniMarket - " + venta.getSerie() + "-" + venta.getIdVenta();
            String cuerpo = "Estimado(a) " + c.getNombres() + ",\n\nGracias por su compra.\nAdjuntamos su comprobante de pago.\n\nAtentamente,\nMiniMarket.";

            emailService.enviarBoletaAsync(c.getEmail(), asunto, cuerpo, pdfBytes, "Comprobante_" + venta.getIdVenta() + ".pdf");

            mostrarAlerta("Correo Enviado", "El comprobante se está enviando a: " + c.getEmail(), Alert.AlertType.INFORMATION);

        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Error Email", "Fallo al generar o enviar el correo: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private String generarTextoRecibo(Venta venta) {
        StringBuilder sb = new StringBuilder();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

        sb.append("============= MINIMARKET S.A.C. =============\n");
        sb.append("\n");
        sb.append(String.format("          %S ELECTRÓNICA\n", venta.getTipoDocumento()));
        sb.append(String.format("             %s-N°%06d\n", venta.getSerie(), venta.getIdVenta()));
        sb.append("----------------------------------------------\n");
        sb.append("Fecha: ").append(venta.getFechaGeneracion().format(dtf)).append("\n");
        sb.append("Cliente: ").append(venta.getCliente().getNombres()).append("\n");
        sb.append(venta.getCliente().getTipoDocumento().name()).append(": ").append(venta.getCliente().getDniruc()).append("\n");
        sb.append("----------------------------------------------\n");
        sb.append(String.format("%-20s %5s %8s %10s\n", "Producto", "Cant.", "P.Unit", "Subtotal"));
        sb.append("----------------------------------------------\n");

        for (DetalleVenta dv : venta.getDetalleVentas()) {
            sb.append(String.format("%-20.20s %5d %8.2f %10.2f\n",
                    dv.getProducto().getNombre(),
                    dv.getCantidad(),
                    dv.getPrecioUnitario(),
                    dv.getSubtotalProducto()));
        }

        sb.append("----------------------------------------------\n");
        sb.append(String.format("%35s S/ %8.2f\n", "OP. GRAVADA:", venta.getSubtotal()));
        sb.append(String.format("%35s S/ %8.2f\n", "IGV (18%):", venta.getIgv()));
        sb.append(String.format("%35s S/ %8.2f\n", "TOTAL A PAGAR:", venta.getTotal()));
        sb.append("\nGracias por su compra!\n");

        return sb.toString();
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @Data
    public static class ProductoVenta {
        private Producto producto;
        private int cantidad;
        private double subtotal;

        public ProductoVenta(Producto producto, int cantidad) {
            this.producto = producto;
            this.cantidad = cantidad;
            actualizarSubtotal();
        }

        public void setCantidad(int cantidad) {
            this.cantidad = cantidad;
            actualizarSubtotal();
        }

        private void actualizarSubtotal() {
            this.subtotal = producto.getPrecioU() * cantidad;
        }
    }
}
