package pe.edu.upeu.conceptos_poo.minimarket.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Usuario;

@Repository
public interface IUsuarioRepository extends ICrudGenericoRepository<Usuario, Long> {

    Usuario findByCorreoIgnoreCase(String correo);
    @Query("SELECT u FROM Usuario u WHERE u.perfil.correo = :correo")
    Usuario buscarUsuarioPorCorreoPerfil(@Param("correo") String correo);
}
