package pe.edu.upeu.conceptos_poo.minimarket.components;

import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import net.sf.jasperreports.engine.JasperPrint;
import win.zqxu.jrviewer.JRViewerFX;

public class ReportDialog {

    private JasperPrint jasperPrint;

    public ReportDialog(JasperPrint jasperPrint) {
        this.jasperPrint = jasperPrint;
    }

    public void show() {
        // 1. Crear un nuevo Stage (Ventana)
        Stage stage = new Stage();
        stage.setTitle("Visualizar Reporte - MiniMarket");

        // 2. Configurar modalidad (bloquea la ventana anterior hasta que se cierre esta)
        stage.initModality(Modality.APPLICATION_MODAL);

        // 3. Crear el visor del reporte
        JRViewerFX viewerFX = new JRViewerFX(jasperPrint);
        viewerFX.setPrefSize(900, 600); // Tamaño sugerido

        // 4. Contenedor raíz
        StackPane root = new StackPane(viewerFX);

        // 5. Crear la escena y asignarla al Stage
        Scene scene = new Scene(root, 900, 600);
        stage.setScene(scene);

        // 6. Mostrar la ventana y esperar
        stage.centerOnScreen();
        stage.showAndWait();
    }
}
