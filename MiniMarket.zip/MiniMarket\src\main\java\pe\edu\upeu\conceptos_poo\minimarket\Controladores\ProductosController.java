package pe.edu.upeu.conceptos_poo.minimarket.Controladores;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.minimarket.components.ColumnInfo;
import pe.edu.upeu.conceptos_poo.minimarket.components.TableViewHelper;
import pe.edu.upeu.conceptos_poo.minimarket.components.ValidationTooltip;
import pe.edu.upeu.conceptos_poo.minimarket.dto.ComboBoxOption;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Categoria;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Producto;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.UnidadMedida;
import pe.edu.upeu.conceptos_poo.minimarket.service.CategoriaIService;
import pe.edu.upeu.conceptos_poo.minimarket.service.ProductoIService;
import pe.edu.upeu.conceptos_poo.minimarket.service.UnidadMedidaService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class ProductosController {

    @FXML private TextField txtFiltroProductos;
    @FXML private TableView<Producto> tableViewProductos;
    @FXML private TextField txtNombreProducto;
    @FXML private TextField txtPrecioUnitario;
    @FXML private TextField txtStockProducto;
    @FXML private ComboBox<ComboBoxOption> cbxCategoriaProducto;
    @FXML private ComboBox<ComboBoxOption> cbxUnidadMedidaProducto;
    @FXML private Button btnGuardarProducto;
    @FXML private Label lblMensajeProducto;

    @Autowired
    private ProductoIService productoService;
    @Autowired private CategoriaIService categoriaService;
    @Autowired private UnidadMedidaService unidadMedidaService;

    private ObservableList<Producto> listaProductosObservable;
    private Long idProductoEditando = null;

    @FXML
    public void initialize() {
        cargarCategorias();
        cargarUnidadesMedida();
        configurarTablaProductos();
        listarProductos();

        txtFiltroProductos.textProperty().addListener((observable, oldValue, newValue) -> filtrarProductos(newValue));
        txtNombreProducto.textProperty().addListener((obs, oldVal, newVal) ->
                marcarError(txtNombreProducto, newVal.trim().isEmpty(), "Ingrese el nombre del producto"));
        txtPrecioUnitario.textProperty().addListener((obs, oldVal, newVal) ->
                validarPrecioVisual(newVal.trim()));
        txtStockProducto.textProperty().addListener((obs, oldVal, newVal) ->
                validarStockVisual(newVal.trim()));
        cbxCategoriaProducto.valueProperty().addListener((obs, oldVal, newVal) ->
                marcarError(cbxCategoriaProducto, newVal == null, "Seleccione una categoría"));
        cbxUnidadMedidaProducto.valueProperty().addListener((obs, oldVal, newVal) ->
                marcarError(cbxUnidadMedidaProducto, newVal == null, "Seleccione una unidad de medida"));
        cancelarEdicionProducto();
    }

    private void cargarCategorias() {
        try {
            List<ComboBoxOption> opciones = categoriaService.listarCombobox();
            cbxCategoriaProducto.setItems(FXCollections.observableArrayList(opciones));
        } catch (Exception e) {
            mostrarMensajeProducto("Error al cargar categorías: " + e.getMessage(), true);
            e.printStackTrace();
        }
    }

    private void cargarUnidadesMedida() {
        try {
            List<ComboBoxOption> opciones = unidadMedidaService.listarCombobox();
            cbxUnidadMedidaProducto.setItems(FXCollections.observableArrayList(opciones));
        } catch (Exception e) {
            mostrarMensajeProducto("Error al cargar unidades de medida: " + e.getMessage(), true);
            e.printStackTrace();
        }
    }

    private void configurarTablaProductos() {
        TableViewHelper<Producto> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columnas = new LinkedHashMap<>();
        columnas.put("ID", new ColumnInfo("id_producto", 60.0));
        columnas.put("Nombre", new ColumnInfo("nombre", 200.0));
        columnas.put("Precio U.", new ColumnInfo("PrecioU", 100.0));
        columnas.put("Stock", new ColumnInfo("stok", 80.0));
        columnas.put("Categoría", new ColumnInfo("categoria.nombre", 150.0));
        columnas.put("Unidad M.", new ColumnInfo("unidadMedida.nombre_medida", 150.0)); // <--- CORREGIDO (antes 'nombre_Medida')

        helper.addColumnsInOrderWithSize(tableViewProductos, columnas, this::editarProducto, this::eliminarProducto);
        tableViewProductos.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
    }

    private void listarProductos() {
        try {
            listaProductosObservable = FXCollections.observableArrayList(productoService.findAllProductos());
            tableViewProductos.setItems(listaProductosObservable);
        } catch (Exception e) {
            mostrarMensajeProducto("Error al listar productos: " + e.getMessage(), true);
            e.printStackTrace();
        }
    }

    private void filtrarProductos(String filtro) {
        if (filtro == null || filtro.isEmpty()) {
            tableViewProductos.setItems(listaProductosObservable);
        }
        else {
            String lowerCaseFilter = filtro.toLowerCase();
            List<Producto> filtradosList = listaProductosObservable.stream()
                    .filter(p -> (p.getNombre() != null && p.getNombre().toLowerCase().contains(lowerCaseFilter)) ||
                            (p.getCategoria() != null && p.getCategoria().getNombre() != null && p.getCategoria().getNombre().toLowerCase().contains(lowerCaseFilter)) ||
                            (String.valueOf(p.getPrecioU()).contains(lowerCaseFilter)) )
                    .collect(Collectors.toList());
            ObservableList<Producto> filtradosObservable = FXCollections.observableArrayList(filtradosList);
            tableViewProductos.setItems(filtradosObservable);
        }
    }

    @FXML
    private void guardarProducto() {
        String nombre = txtNombreProducto.getText().trim();
        String precioStr = txtPrecioUnitario.getText().trim();
        String stockStr = txtStockProducto.getText().trim();
        ComboBoxOption categoriaSeleccionada = cbxCategoriaProducto.getSelectionModel().getSelectedItem();
        ComboBoxOption unidadSeleccionada = cbxUnidadMedidaProducto.getSelectionModel().getSelectedItem();

        limpiarEstilosErrorProducto();
        boolean nombreInvalido = nombre.isEmpty();
        boolean precioInvalido = !precioValido(precioStr);
        boolean stockInvalido = !stockValido(stockStr);
        boolean categoriaInvalida = categoriaSeleccionada == null;
        boolean unidadInvalida = unidadSeleccionada == null;

        marcarError(txtNombreProducto, nombreInvalido, "Ingrese el nombre del producto");
        marcarError(txtPrecioUnitario, precioInvalido,
                precioStr.isEmpty() ? "Ingrese el precio unitario" : "El precio del producto debe ser positivo");
        marcarError(txtStockProducto, stockInvalido,
                stockStr.isEmpty() ? "Ingrese el stock" : "El stock debe ser un número entero positivo o cero");
        marcarError(cbxCategoriaProducto, categoriaInvalida, "Seleccione una categoría");
        marcarError(cbxUnidadMedidaProducto, unidadInvalida, "Seleccione una unidad de medida");

        if (nombreInvalido || precioInvalido || stockInvalido || categoriaInvalida || unidadInvalida) {
            Control primerInvalido = obtenerPrimerCampoInvalido(nombreInvalido, precioInvalido,
                    stockInvalido, categoriaInvalida, unidadInvalida);
            String mensaje = mensajePrimerError(nombreInvalido, precioInvalido, stockInvalido,
                    categoriaInvalida, unidadInvalida, precioStr, stockStr);
            mostrarMensajeProducto(mensaje, true);
            primerInvalido.requestFocus();
            ValidationTooltip.mostrar(primerInvalido);
            return;
        }

        double precio;
        long stock;
        try {
            precio = Double.parseDouble(precioStr);
            if (precio <= 0) throw new NumberFormatException("Precio debe ser positivo");
        } catch (NumberFormatException e) {
            mostrarMensajeProducto("Ingrese un precio válido (número positivo).", true);
            return;
        }
        try {
            stock = Long.parseLong(stockStr);
            if (stock < 0) throw new NumberFormatException("Stock no puede ser negativo");
        } catch (NumberFormatException e) {
            mostrarMensajeProducto("Ingrese un stock válido (número entero positivo o cero).", true);
            return;
        }

        try {
            Producto producto = (idProductoEditando != null) ? productoService.findProductoById(idProductoEditando) : new Producto();
            if (producto == null && idProductoEditando != null) {
                mostrarMensajeProducto("Error: No se encontró el producto a editar.", true);
                return;
            }
            if (producto == null) producto = new Producto();

            producto.setNombre(nombre);
            producto.setPrecioU(precio);
            producto.setStok(stock);

            Categoria categoria = categoriaService.findById(Long.parseLong(categoriaSeleccionada.getKey()));
            UnidadMedida unidad = unidadMedidaService.findById(Long.parseLong(unidadSeleccionada.getKey()));

            if (categoria == null || unidad == null) {
                mostrarMensajeProducto("Error: Categoría o Unidad de Medida no válidas.", true);
                return;
            }
            producto.setCategoria(categoria);
            producto.setUnidadMedida(unidad);

            if (idProductoEditando == null) {
                productoService.saveProducto(producto);
                mostrarMensajeProducto("Producto creado exitosamente.", false);
            } else {
                producto.setId_producto(idProductoEditando);
                productoService.updateProducto(producto);
                mostrarMensajeProducto("Producto actualizado exitosamente.", false);
            }

            cancelarEdicionProducto();
            listarProductos();

        } catch (Exception e) {
            mostrarMensajeProducto("Error al guardar producto: " + e.getMessage(), true);
            e.printStackTrace();
        }
    }

    private void editarProducto(Producto producto) {
        idProductoEditando = producto.getId_producto();
        txtNombreProducto.setText(producto.getNombre());
        txtPrecioUnitario.setText(String.valueOf(producto.getPrecioU()));
        txtStockProducto.setText(String.valueOf(producto.getStok()));

        String catIdStr = String.valueOf(producto.getCategoria().getIdCategoria());
        cbxCategoriaProducto.getItems().stream()
                .filter(opt -> opt.getKey().equals(catIdStr))
                .findFirst()
                .ifPresent(opt -> cbxCategoriaProducto.setValue(opt));

        // --- SECCIÓN CORREGIDA ---
        String umIdStr = String.valueOf(producto.getUnidadMedida().getId_unidad()); // <--- CORREGIDO (antes 'getId_unidad_medida')
        // --- FIN DE CORRECCIÓN ---

        cbxUnidadMedidaProducto.getItems().stream()
                .filter(opt -> opt.getKey().equals(umIdStr))
                .findFirst()
                .ifPresent(opt -> cbxUnidadMedidaProducto.setValue(opt));

        lblMensajeProducto.setText("Editando producto ID: " + idProductoEditando);
        lblMensajeProducto.setStyle("-fx-text-fill: blue;");
        btnGuardarProducto.setText("Actualizar");
    }

    private void eliminarProducto(Producto producto) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "¿Está seguro de eliminar el producto '" + producto.getNombre() + "'?", ButtonType.YES, ButtonType.NO);
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                try {
                    productoService.deleteProductoById(producto.getId_producto());
                    mostrarMensajeProducto("Producto eliminado exitosamente.", false);
                    listarProductos();
                } catch (Exception e) {
                    mostrarMensajeProducto("Error al eliminar producto: " + e.getMessage(), true);
                    e.printStackTrace();
                }
            }
        });
    }

    @FXML
    private void cancelarEdicionProducto() {
        idProductoEditando = null;
        txtNombreProducto.clear();
        txtPrecioUnitario.clear();
        txtStockProducto.clear();
        cbxCategoriaProducto.getSelectionModel().clearSelection();
        cbxUnidadMedidaProducto.getSelectionModel().clearSelection();
        lblMensajeProducto.setText("");
        btnGuardarProducto.setText("Guardar");
        limpiarEstilosErrorProducto();
    }

    private void mostrarMensajeProducto(String mensaje, boolean esError) {
        lblMensajeProducto.setText(mensaje);
        if (esError) {
            lblMensajeProducto.setStyle("-fx-text-fill: red;");
        }
        else {
            lblMensajeProducto.setStyle("-fx-text-fill: green;");
        }
    }

    private void limpiarEstilosErrorProducto() {
        marcarError(txtNombreProducto, false, "");
        marcarError(txtPrecioUnitario, false, "");
        marcarError(txtStockProducto, false, "");
        marcarError(cbxCategoriaProducto, false, "");
        marcarError(cbxUnidadMedidaProducto, false, "");
    }

    private void validarPrecioVisual(String valor) {
        marcarError(txtPrecioUnitario, !precioValido(valor),
                valor.isEmpty() ? "Ingrese el precio unitario" : "El precio del producto debe ser positivo");
    }

    private void validarStockVisual(String valor) {
        marcarError(txtStockProducto, !stockValido(valor),
                valor.isEmpty() ? "Ingrese el stock" : "El stock debe ser un número entero positivo o cero");
    }

    private boolean precioValido(String valor) {
        if (valor == null || valor.isEmpty()) return false;
        try {
            double precio = Double.parseDouble(valor);
            return Double.isFinite(precio) && precio > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private boolean stockValido(String valor) {
        if (valor == null || valor.isEmpty()) return false;
        try {
            return Long.parseLong(valor) >= 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private Control obtenerPrimerCampoInvalido(boolean nombre, boolean precio, boolean stock,
                                                boolean categoria, boolean unidad) {
        if (nombre) return txtNombreProducto;
        if (precio) return txtPrecioUnitario;
        if (stock) return txtStockProducto;
        if (categoria) return cbxCategoriaProducto;
        return cbxUnidadMedidaProducto;
    }

    private String mensajePrimerError(boolean nombre, boolean precio, boolean stock,
                                      boolean categoria, boolean unidad,
                                      String precioTexto, String stockTexto) {
        if (nombre) return "El nombre del producto es obligatorio.";
        if (precio) return precioTexto.isEmpty()
                ? "El precio unitario es obligatorio."
                : "El precio del producto debe ser positivo.";
        if (stock) return stockTexto.isEmpty()
                ? "El stock es obligatorio."
                : "El stock debe ser un número entero positivo o cero.";
        if (categoria) return "La categoría es obligatoria.";
        if (unidad) return "La unidad de medida es obligatoria.";
        return "Complete los campos obligatorios.";
    }

    private void marcarError(Control control, boolean error, String mensaje) {
        ValidationTooltip.marcar(control, error, mensaje);
    }
}
