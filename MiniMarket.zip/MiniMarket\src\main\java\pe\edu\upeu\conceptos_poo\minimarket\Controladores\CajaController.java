package pe.edu.upeu.conceptos_poo.minimarket.Controladores;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.minimarket.service.CajaService;

@Controller
public class CajaController {
    @FXML private TextField txtMontoInicial;
    @FXML private Button btnAbrir;
    @FXML private TextField txtMontoReal;
    @FXML private Button btnCerrar;
    @FXML private Label lblEstado;

    @Autowired private CajaService cajaService;

    @FXML
    public void initialize() {
        actualizarEstado();
    }

    private void actualizarEstado() {
        boolean abierta = cajaService.hayCajaAbierta();
        btnAbrir.setDisable(abierta);
        txtMontoInicial.setDisable(abierta);

        btnCerrar.setDisable(!abierta);
        txtMontoReal.setDisable(!abierta);

        lblEstado.setText(abierta ? "Estado: CAJA ABIERTA" : "Estado: CAJA CERRADA");
        lblEstado.setStyle(abierta ? "-fx-text-fill: green;" : "-fx-text-fill: red;");
    }

    @FXML
    private void abrirCaja() {
        try {
            double monto = parseMonto(txtMontoInicial.getText(), "monto inicial");
            cajaService.abrirCaja(monto);
            txtMontoInicial.clear();
            actualizarEstado();
            new Alert(Alert.AlertType.INFORMATION, "Caja abierta correctamente.").showAndWait();
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Error al abrir caja: " + e.getMessage()).showAndWait();
        }
    }

    @FXML
    private void cerrarCaja() {
        try {
            double monto = parseMonto(txtMontoReal.getText(), "dinero en caja");
            cajaService.cerrarCaja(monto);
            txtMontoReal.clear();
            actualizarEstado();
            new Alert(Alert.AlertType.INFORMATION, "Caja cerrada correctamente.").showAndWait();
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Error al cerrar caja: " + e.getMessage()).showAndWait();
        }
    }

    private double parseMonto(String texto, String nombreCampo) {
        if (texto == null || texto.trim().isEmpty()) {
            throw new IllegalArgumentException("Ingresa el " + nombreCampo + ".");
        }

        try {
            return Double.parseDouble(texto.trim().replace(",", "."));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Ingresa un valor numerico valido para " + nombreCampo + ".");
        }
    }
}
