package pe.edu.upeu.conceptos_poo.minimarket.components;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.geometry.Bounds;
import javafx.scene.control.Control;
import javafx.scene.control.Tooltip;
import javafx.util.Duration;

/** Utilidad visual para resaltar controles inválidos y explicar el error. */
public final class ValidationTooltip {
    private static final String ERROR_STYLE =
            "-fx-border-color: #dc3545; -fx-border-width: 2px; -fx-border-radius: 3px;";
    private static final String TOOLTIP_STYLE =
            "-fx-background-color: #c62828; -fx-text-fill: white; " +
            "-fx-font-size: 13px; -fx-padding: 8 12; -fx-background-radius: 4px;";

    private ValidationTooltip() {
    }

    public static void marcar(Control control, boolean error, String mensaje) {
        if (error) {
            control.setStyle(ERROR_STYLE);
            Tooltip tooltip = control.getTooltip();
            if (tooltip == null) {
                tooltip = new Tooltip();
                control.setTooltip(tooltip);
            }
            tooltip.setText("⚠  " + mensaje);
            tooltip.setStyle(TOOLTIP_STYLE);
            tooltip.setAutoHide(true);
        } else {
            control.setStyle("");
            Tooltip tooltip = control.getTooltip();
            if (tooltip != null) tooltip.hide();
            control.setTooltip(null);
        }
    }

    /** Muestra temporalmente el mensaje al lado del primer campo inválido. */
    public static void mostrar(Control control) {
        if (control == null || control.getTooltip() == null) return;
        Platform.runLater(() -> {
            Bounds bounds = control.localToScreen(control.getBoundsInLocal());
            if (bounds == null) return;

            Tooltip tooltip = control.getTooltip();
            tooltip.show(control, bounds.getMaxX() + 8, bounds.getMinY());
            PauseTransition espera = new PauseTransition(Duration.seconds(3));
            espera.setOnFinished(event -> tooltip.hide());
            espera.play();
        });
    }
}
