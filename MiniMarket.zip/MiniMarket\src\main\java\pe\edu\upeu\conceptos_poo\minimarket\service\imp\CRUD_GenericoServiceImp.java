package pe.edu.upeu.conceptos_poo.minimarket.service.imp;

import pe.edu.upeu.conceptos_poo.minimarket.Exeption.ModelNotFoundException;
import pe.edu.upeu.conceptos_poo.minimarket.repository.ICrudGenericoRepository;
import pe.edu.upeu.conceptos_poo.minimarket.service.CRUD_GenericoSefvice_Interface;

import java.util.List;

public abstract class CRUD_GenericoServiceImp <T,ID> implements CRUD_GenericoSefvice_Interface<T,ID> {

    protected abstract ICrudGenericoRepository<T, ID> getRepository();
    @Override
    public T save(T t) {
        return getRepository().save(t);
    }

    @Override
    public T update(ID id, T t) {
        getRepository().findById(id).orElseThrow(()-> new ModelNotFoundException("ID NOT FOUND:"+id));
        return  getRepository().save(t);
    }

    @Override
    public List<T> findAll() {
        return getRepository().findAll();
    }

    @Override
    public T findById(ID id) {
        return getRepository().findById(id).orElseThrow(()-> new ModelNotFoundException("ID NOT FOUND:"+id));
    }

    @Override
    public void delete(ID id) {
        if(!this.existsById(id)){
            throw new ModelNotFoundException("ID NOT EXIST:"+id);
        }
        getRepository().deleteById(id);
    }

    @Override
    public boolean existsById(ID id) {
        return getRepository().existsById(id);
    }

    // ----- INICIO DE LA MODIFICACIÓN -----
    @Override
    public T findByIdOrNull(ID id) {
        // Esta implementación devuelve null si no lo encuentra, sin lanzar error.
        return getRepository().findById(id).orElse(null);
    }
    // ----- FIN DE LA MODIFICACIÓN -----
}