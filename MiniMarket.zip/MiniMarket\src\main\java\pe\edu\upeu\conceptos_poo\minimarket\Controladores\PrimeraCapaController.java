package pe.edu.upeu.conceptos_poo.minimarket.Controladores;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.minimarket.components.StageManager;
import pe.edu.upeu.conceptos_poo.minimarket.dto.SessionManager;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Usuario;
import pe.edu.upeu.conceptos_poo.minimarket.service.UsuarioService;

import java.io.IOException;

@Controller
public class PrimeraCapaController {
    // Inyectamos el contexto de Spring para cargar los siguientes controladores
    @Autowired
    private ConfigurableApplicationContext applicationContext;

    // Enlazamos los botones definidos en PrimeraCapa.fxml
    @FXML
    private Button loginButton;

    @FXML
    private Button registerButton;

    /**
     * El método initialize() se llama automáticamente después de que
     * se cargan los componentes FXML.
     */
    @FXML
    public void initialize() {
        // Asignamos las acciones a los botones desde Java
        loginButton.setOnAction(event -> IniciarSesion());
        registerButton.setOnAction(event -> Registrar());
    }
    private void IniciarSesion() {
        System.out.println("Cargando pantalla de login...");

        try {
            Stage stage = (Stage) loginButton.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            fxmlLoader.setControllerFactory(applicationContext::getBean);
            Parent parent = fxmlLoader.load();
            Scene scene = new Scene(parent);
            stage.setScene(scene);

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error al cargar el FXML: /fxml/login.fxml");
        } catch (NullPointerException e) {
            // Esto puede pasar si loginButton aún no está en una escena cuando se llama
            e.printStackTrace();
            System.err.println("Error: No se pudo obtener la ventana desde el botón. Asegúrate de que la interfaz gráfica se ha mostrado.");
        }
    }
    private void Registrar() {
        System.out.println("Botón 'Registrarse' presionado. Debes crear register.fxml");

        try {
             Stage stage = (Stage) registerButton.getScene().getWindow();
             FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/registrarce_cliente.fxml"));
             fxmlLoader.setControllerFactory(applicationContext::getBean);
             Parent parent = fxmlLoader.load();
             Scene scene = new Scene(parent);
             stage.setScene(scene);
         } catch (IOException e) {
             e.printStackTrace();
         } catch (NullPointerException e) {
            e.printStackTrace();
            System.err.println("Error al obtener la ventana para registro.");
        }
    }
}
