package pe.edu.upeu.conceptos_poo.minimarket;

import javafx.application.Application;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Punto de entrada de la aplicación.
 *
 * Esta clase no debe heredar de javafx.application.Application. De esa manera
 * IntelliJ puede ejecutarla directamente con el classpath de Maven sin que el
 * lanzador de Java intente buscar JavaFX únicamente en el module-path.
 */
@SpringBootApplication
public class MiniMarketApplication {

    public static void main(String[] args) {
        configureDatabaseLocation();
        Application.launch(MiniMarketFxApplication.class, args);
    }

    /**
     * Localiza la base incluida en el proyecto tanto si IntelliJ abre directamente
     * el módulo como si abre la carpeta exterior creada al descomprimir el ZIP.
     */
    private static void configureDatabaseLocation() {
        try {
            Path nestedDatabase = Path.of("MiniMarket", "data", "MiniMarket.db");
            Path directDatabase = Path.of("data", "MiniMarket.db");
            Path database = Files.isRegularFile(nestedDatabase) ? nestedDatabase : directDatabase;

            Path absoluteDatabase = database.toAbsolutePath().normalize();
            Files.createDirectories(absoluteDatabase.getParent());
            System.setProperty("minimarket.database.path",
                    absoluteDatabase.toString().replace('\\', '/'));
            System.out.println("Base de datos MiniMarket: " + absoluteDatabase);
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo crear la carpeta de datos del programa.", e);
        }
    }

    @Bean
    public CommandLineRunner createEncryptedPassword(PasswordEncoder passwordEncoder) {
        return args -> {
            // Bean disponible para tareas de inicialización que requieran PasswordEncoder.
        };
    }
}
