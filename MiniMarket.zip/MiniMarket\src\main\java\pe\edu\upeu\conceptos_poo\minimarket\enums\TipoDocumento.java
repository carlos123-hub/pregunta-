package pe.edu.upeu.conceptos_poo.minimarket.enums;

public enum TipoDocumento {
    DNI,
    RUC
}
