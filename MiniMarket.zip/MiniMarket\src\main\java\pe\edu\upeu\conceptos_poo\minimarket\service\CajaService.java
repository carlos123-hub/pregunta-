package pe.edu.upeu.conceptos_poo.minimarket.service;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upeu.conceptos_poo.minimarket.dto.SessionManager;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Caja;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Venta;
import pe.edu.upeu.conceptos_poo.minimarket.repository.ICajaRepository;
import pe.edu.upeu.conceptos_poo.minimarket.repository.ICrudGenericoRepository;
import pe.edu.upeu.conceptos_poo.minimarket.service.imp.CRUD_GenericoServiceImp;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class CajaService extends CRUD_GenericoServiceImp<Caja, Long> {

    @Autowired private ICajaRepository cajaRepository;
    @Autowired private VentaService ventaService;

    @Override
    protected ICrudGenericoRepository<Caja, Long> getRepository() {
        return cajaRepository;
    }

    public Caja abrirCaja(double montoInicial) {
        if (montoInicial < 0) {
            throw new RuntimeException("El monto inicial no puede ser negativo.");
        }

        String usuario = obtenerUsuarioActual();
        if (cajaRepository.buscarCajaAbierta(usuario).isPresent()) {
            throw new RuntimeException("Ya tienes una caja abierta.");
        }

        Caja caja = new Caja();
        caja.setFechaApertura(LocalDateTime.now());
        caja.setMontoInicial(montoInicial);
        caja.setMontoFinal(montoInicial);
        caja.setMontoReal(0);
        caja.setUsuario(usuario);
        caja.setEstado("ABIERTA");
        return cajaRepository.save(caja);
    }

    public Caja cerrarCaja(double montoReal) {
        if (montoReal < 0) {
            throw new RuntimeException("El monto real no puede ser negativo.");
        }

        String usuario = obtenerUsuarioActual();
        Caja caja = cajaRepository.buscarCajaAbierta(usuario)
                .orElseThrow(() -> new RuntimeException("No hay caja abierta para cerrar."));

        caja.setFechaCierre(LocalDateTime.now());
        caja.setMontoFinal(calcularMontoFinal(caja));
        caja.setMontoReal(montoReal);
        caja.setEstado("CERRADA");
        return cajaRepository.save(caja);
    }

    public boolean hayCajaAbierta() {
        return cajaRepository.buscarCajaAbierta(obtenerUsuarioActual()).isPresent();
    }

    private double calcularMontoFinal(Caja caja) {
        LocalDateTime inicio = caja.getFechaApertura();
        LocalDateTime fin = LocalDateTime.now();
        List<Venta> ventas = ventaService.findVentasBetweenFechas(inicio, fin);
        double totalVentas = ventas.stream().mapToDouble(Venta::getTotal).sum();
        return caja.getMontoInicial() + totalVentas;
    }

    private String obtenerUsuarioActual() {
        String usuario = SessionManager.getInstance().getUserName();
        if (usuario == null || usuario.trim().isEmpty()) {
            return "CAJERO";
        }
        return usuario.trim();
    }
}
