package pe.edu.upeu.conceptos_poo.minimarket.repository;

import pe.edu.upeu.conceptos_poo.minimarket.modelos.UnidadMedida;

public interface IUnidadMedidaRepository extends ICrudGenericoRepository<UnidadMedida,Long>{

}
