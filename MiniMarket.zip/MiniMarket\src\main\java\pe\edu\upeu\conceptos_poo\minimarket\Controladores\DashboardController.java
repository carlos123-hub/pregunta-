package pe.edu.upeu.conceptos_poo.minimarket.Controladores;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.util.Duration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Compra;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Producto;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Venta;
import pe.edu.upeu.conceptos_poo.minimarket.service.CompraService;
import pe.edu.upeu.conceptos_poo.minimarket.service.ProductoIService;
import pe.edu.upeu.conceptos_poo.minimarket.service.VentaService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class DashboardController {

    @FXML private Label lblTotalVentasHoy;
    @FXML private Label lblProductosBajoStock;
    @FXML private Label lblTotalComprasHoy; // Nueva etiqueta

    @FXML private BarChart<String, Number> barChartVentas;
    @FXML private PieChart pieChartProductos;
    @FXML private BarChart<String, Number> barChartCompras;     // Nuevo gráfico
    @FXML private BarChart<String, Number> barChartComparativo; // Nuevo gráfico

    @Autowired private VentaService ventaService;
    @Autowired private ProductoIService productoService;
    @Autowired private CompraService compraService; // Nuevo servicio
    private Timeline actualizadorDashboard;

    @FXML
    public void initialize() {
        refrescarDashboard();
        iniciarActualizacionAutomatica();
    }

    public void refrescarDashboard() {
        cargarTarjetas();
        cargarGraficoVentas();
        cargarGraficoPastel();
        cargarGraficoCompras();
        cargarGraficoComparativo();
    }

    private void iniciarActualizacionAutomatica() {
        actualizadorDashboard = new Timeline(new KeyFrame(Duration.seconds(3), event -> refrescarDashboard()));
        actualizadorDashboard.setCycleCount(Timeline.INDEFINITE);
        actualizadorDashboard.play();

        lblTotalVentasHoy.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (oldScene != null && newScene == null && actualizadorDashboard != null) {
                actualizadorDashboard.stop();
            }
        });
    }

    private void cargarTarjetas() {
        LocalDateTime inicioHoy = LocalDate.now().atStartOfDay();
        LocalDateTime finHoy = LocalDate.now().atTime(23, 59, 59);

        // Ventas Hoy
        List<Venta> ventasHoy = ventaService.findVentasBetweenFechas(inicioHoy, finHoy);
        double totalVentas = ventasHoy.stream().mapToDouble(Venta::getTotal).sum();
        lblTotalVentasHoy.setText("S/ " + String.format("%.2f", totalVentas));

        // Compras Hoy
        List<Compra> comprasHoy = compraService.findComprasBetweenFechas(inicioHoy, finHoy);
        double totalCompras = comprasHoy.stream().mapToDouble(Compra::getTotal).sum();
        lblTotalComprasHoy.setText("S/ " + String.format("%.2f", totalCompras));

        // Productos Bajo Stock
        List<Producto> productos = productoService.findAllProductos();
        long bajosStock = productos.stream().filter(p -> p.getStok() < 5).count();
        lblProductosBajoStock.setText(String.valueOf(bajosStock));
        if (bajosStock > 0) {
            lblProductosBajoStock.setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
        } else {
            lblProductosBajoStock.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");
        }
    }

    private void cargarGraficoVentas() {
        barChartVentas.getData().clear();
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Ventas");

        LocalDate fecha = LocalDate.now().minusDays(6);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM");

        for (int i = 0; i < 7; i++) {
            LocalDateTime inicio = fecha.atStartOfDay();
            LocalDateTime fin = fecha.atTime(23, 59, 59);
            List<Venta> ventasDia = ventaService.findVentasBetweenFechas(inicio, fin);
            double total = ventasDia.stream().mapToDouble(Venta::getTotal).sum();

            series.getData().add(new XYChart.Data<>(fecha.format(fmt), total));
            fecha = fecha.plusDays(1);
        }
        barChartVentas.getData().add(series);
    }

    private void cargarGraficoPastel() {
        List<Producto> productos = productoService.findAllProductos();
        Map<String, Long> conteo = productos.stream()
                .collect(Collectors.groupingBy(p -> p.getCategoria() != null ? p.getCategoria().getNombre() : "Sin categoria", Collectors.counting()));

        ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList();
        conteo.forEach((cat, cant) -> pieData.add(new PieChart.Data(cat, cant)));

        pieChartProductos.setData(pieData);
    }

    // --- NUEVOS GRÁFICOS ---

    private void cargarGraficoCompras() {
        barChartCompras.getData().clear();
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Compras (Inversión)");

        LocalDate fecha = LocalDate.now().minusDays(6);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM");

        for (int i = 0; i < 7; i++) {
            LocalDateTime inicio = fecha.atStartOfDay();
            LocalDateTime fin = fecha.atTime(23, 59, 59);
            List<Compra> comprasDia = compraService.findComprasBetweenFechas(inicio, fin);
            double total = comprasDia.stream().mapToDouble(Compra::getTotal).sum();

            series.getData().add(new XYChart.Data<>(fecha.format(fmt), total));
            fecha = fecha.plusDays(1);
        }
        barChartCompras.getData().add(series);
    }

    private void cargarGraficoComparativo() {
        barChartComparativo.getData().clear();
        XYChart.Series<String, Number> seriesVentas = new XYChart.Series<>();
        seriesVentas.setName("Ingresos (Ventas)");

        XYChart.Series<String, Number> seriesCompras = new XYChart.Series<>();
        seriesCompras.setName("Egresos (Compras)");

        LocalDate fecha = LocalDate.now().minusDays(6);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM");

        for (int i = 0; i < 7; i++) {
            LocalDateTime inicio = fecha.atStartOfDay();
            LocalDateTime fin = fecha.atTime(23, 59, 59);
            String fechaLabel = fecha.format(fmt);

            // Datos Ventas
            List<Venta> ventasDia = ventaService.findVentasBetweenFechas(inicio, fin);
            double totalVentas = ventasDia.stream().mapToDouble(Venta::getTotal).sum();
            seriesVentas.getData().add(new XYChart.Data<>(fechaLabel, totalVentas));

            // Datos Compras
            List<Compra> comprasDia = compraService.findComprasBetweenFechas(inicio, fin);
            double totalCompras = comprasDia.stream().mapToDouble(Compra::getTotal).sum();
            seriesCompras.getData().add(new XYChart.Data<>(fechaLabel, totalCompras));

            fecha = fecha.plusDays(1);
        }

        barChartComparativo.getData().addAll(seriesVentas, seriesCompras);
    }
}
