package pe.edu.upeu.conceptos_poo.minimarket;

/** Compatibilidad con configuraciones antiguas que ejecutaban esta clase. */
public class Application {
    public static void main(String[] args) {
        MiniMarketApplication.main(args);
    }
}
