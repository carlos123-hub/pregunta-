package pe.edu.upeu.conceptos_poo.minimarket.Controladores;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Producto;
import pe.edu.upeu.conceptos_poo.minimarket.service.EmailService;
import pe.edu.upeu.conceptos_poo.minimarket.service.ProductoIService;
import pe.edu.upeu.conceptos_poo.minimarket.service.ReportService;
import pe.edu.upeu.conceptos_poo.minimarket.utils.PrinterUtil;

import javax.print.PrintException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class BuscadorPreciosController {

    @FXML private TextField txtBuscar;
    @FXML private TableView<Producto> tablaResultados;
    @FXML private TableColumn<Producto, String> colProducto;
    @FXML private TableColumn<Producto, String> colCategoria;
    @FXML private TableColumn<Producto, String> colPrecio;
    @FXML private TableColumn<Producto, Long> colStock;

    @Autowired private ProductoIService productoService;
    @Autowired private ReportService reportService;
    @Autowired private EmailService emailService;

    private List<Producto> todosLosProductos;

    @FXML
    public void initialize() {
        configurarTabla();
        cargarDatos();
        txtBuscar.textProperty().addListener((obs, oldVal, newVal) -> filtrar(newVal));
    }

    private void cargarDatos() {
        todosLosProductos = productoService.findAllProductos();
        tablaResultados.setItems(FXCollections.observableArrayList(todosLosProductos));
    }

    private void configurarTabla() {
        colProducto.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getNombre()));
        colCategoria.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getCategoria().getNombre()));
        colPrecio.setCellValueFactory(cell -> new SimpleStringProperty("S/ " + cell.getValue().getPrecioU()));
        colStock.setCellValueFactory(new PropertyValueFactory<>("stok"));
    }

    private void filtrar(String texto) {
        if (texto == null || texto.isEmpty()) {
            tablaResultados.setItems(FXCollections.observableArrayList(todosLosProductos));
        } else {
            List<Producto> filtrados = todosLosProductos.stream()
                    .filter(p -> p.getNombre().toLowerCase().contains(texto.toLowerCase()))
                    .collect(Collectors.toList());
            tablaResultados.setItems(FXCollections.observableArrayList(filtrados));
        }
    }

    // --- NUEVO: Imprimir Lista (Ticket) ---
    @FXML
    private void imprimirLista() {
        List<Producto> productosVisibles = tablaResultados.getItems();
        if (productosVisibles.isEmpty()) {
            mostrarAlerta("Lista Vacía", "No hay productos para imprimir.", Alert.AlertType.WARNING);
            return;
        }

        try {
            List<String> impresoras = PrinterUtil.getImpresoras();
            if (impresoras.isEmpty()) {
                mostrarAlerta("Error", "No se encontraron impresoras.", Alert.AlertType.ERROR);
                return;
            }

            ChoiceDialog<String> dialog = new ChoiceDialog<>(impresoras.get(0), impresoras);
            dialog.setTitle("Imprimir Lista de Precios");
            dialog.setHeaderText("Seleccione la impresora:");
            dialog.setContentText("Impresora:");

            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                String textoTicket = generarTextoTicket(productosVisibles);
                PrinterUtil.imprimirTexto(textoTicket, result.get());
                mostrarAlerta("Éxito", "Enviado a impresora.", Alert.AlertType.INFORMATION);
            }

        } catch (PrintException e) {
            mostrarAlerta("Error de Impresión", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // --- NUEVO: Enviar Proforma por Correo (PDF) ---
    @FXML
    private void enviarProforma() {
        List<Producto> productosVisibles = tablaResultados.getItems();
        if (productosVisibles.isEmpty()) {
            mostrarAlerta("Lista Vacía", "No hay productos para la proforma.", Alert.AlertType.WARNING);
            return;
        }

        TextInputDialog emailDialog = new TextInputDialog();
        emailDialog.setTitle("Enviar Proforma");
        emailDialog.setHeaderText("Enviar lista de precios actual por correo.");
        emailDialog.setContentText("Ingrese correo del cliente:");

        Optional<String> emailRes = emailDialog.showAndWait();
        if (emailRes.isPresent() && !emailRes.get().trim().isEmpty()) {
            String email = emailRes.get().trim();

            try {
                // Generar PDF
                byte[] pdfBytes = reportService.generarProformaPdf(productosVisibles);

                // Enviar Correo
                String asunto = "Cotización / Lista de Precios - MiniMarket";
                String cuerpo = "Hola,\n\nAdjuntamos la lista de precios solicitada.\n\nAtentamente,\nMiniMarket.";

                emailService.enviarBoletaAsync(email, asunto, cuerpo, pdfBytes, "Proforma_Precios.pdf");
                mostrarAlerta("Enviando", "La proforma se está enviando a " + email, Alert.AlertType.INFORMATION);

            } catch (Exception e) {
                e.printStackTrace();
                mostrarAlerta("Error", "No se pudo generar o enviar el reporte: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    private String generarTextoTicket(List<Producto> productos) {
        StringBuilder sb = new StringBuilder();
        sb.append("===== LISTA DE PRECIOS =====\n");
        sb.append("MINIMARKET S.A.C.\n");
        sb.append("Fecha: ").append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yy HH:mm"))).append("\n");
        sb.append("--------------------------------\n");
        sb.append(String.format("%-20s %10s\n", "Producto", "Precio"));
        sb.append("--------------------------------\n");
        for (Producto p : productos) {
            // Cortar nombre si es muy largo para ticket
            String nombre = p.getNombre().length() > 20 ? p.getNombre().substring(0, 20) : p.getNombre();
            sb.append(String.format("%-20s S/ %8.2f\n", nombre, p.getPrecioU()));
        }
        sb.append("--------------------------------\n");
        sb.append("Total Items: ").append(productos.size()).append("\n\n\n");
        return sb.toString();
    }

    private void mostrarAlerta(String titulo, String msg, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
