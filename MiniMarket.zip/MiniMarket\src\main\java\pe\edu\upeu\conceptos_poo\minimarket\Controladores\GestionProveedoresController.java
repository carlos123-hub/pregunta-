package pe.edu.upeu.conceptos_poo.minimarket.Controladores;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.minimarket.components.ColumnInfo;
import pe.edu.upeu.conceptos_poo.minimarket.components.TableViewHelper;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Proveedor;
import pe.edu.upeu.conceptos_poo.minimarket.service.ProveedorService;

import java.util.LinkedHashMap;

@Controller
public class GestionProveedoresController {

    @FXML private TextField txtRuc, txtRazonSocial, txtTelefono, txtDireccion;
    @FXML private TableView<Proveedor> tablaProveedores;
    @FXML private Label lblMensaje;
    @FXML private Button btnGuardar;

    @Autowired private ProveedorService proveedorService;

    private Long idEditando = null;

    @FXML
    public void initialize() {
        configurarTabla();
        listarProveedores();
    }

    private void configurarTabla() {
        TableViewHelper<Proveedor> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columnas = new LinkedHashMap<>();
        columnas.put("RUC/DNI", new ColumnInfo("rucDni", 100.0));
        columnas.put("Razón Social", new ColumnInfo("razonSocial", 200.0));
        columnas.put("Teléfono", new ColumnInfo("telefono", 100.0));
        columnas.put("Dirección", new ColumnInfo("direccion", 150.0));

        helper.addColumnsInOrderWithSize(tablaProveedores, columnas, this::editarProveedor, this::eliminarProveedor);
    }

    private void listarProveedores() {
        try {
            tablaProveedores.setItems(FXCollections.observableArrayList(proveedorService.findAll()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void guardarProveedor() {
        if (txtRuc.getText().isEmpty() || txtRazonSocial.getText().isEmpty()) {
            lblMensaje.setText("RUC y Razón Social son obligatorios.");
            lblMensaje.setStyle("-fx-text-fill: red;");
            return;
        }

        try {
            Proveedor p;
            if (idEditando != null) {
                p = proveedorService.findById(idEditando);
                if (p == null) p = new Proveedor();
            } else {
                p = new Proveedor();
            }

            p.setRucDni(txtRuc.getText());
            p.setRazonSocial(txtRazonSocial.getText());
            p.setTelefono(txtTelefono.getText());
            p.setDireccion(txtDireccion.getText());

            if (idEditando != null) {
                proveedorService.update(idEditando, p);
            } else {
                proveedorService.save(p);
            }

            limpiarFormulario();
            listarProveedores();
            lblMensaje.setText("Proveedor guardado correctamente.");
            lblMensaje.setStyle("-fx-text-fill: green;");

        } catch (Exception e) {
            lblMensaje.setText("Error al guardar: " + e.getMessage());
            lblMensaje.setStyle("-fx-text-fill: red;");
        }
    }

    private void editarProveedor(Proveedor p) {
        idEditando = p.getIdProveedor();
        txtRuc.setText(p.getRucDni());
        txtRazonSocial.setText(p.getRazonSocial());
        txtTelefono.setText(p.getTelefono());
        txtDireccion.setText(p.getDireccion());
        btnGuardar.setText("Actualizar");
        lblMensaje.setText("Editando proveedor ID: " + idEditando);
        lblMensaje.setStyle("-fx-text-fill: blue;");
    }

    private void eliminarProveedor(Proveedor p) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "¿Eliminar a " + p.getRazonSocial() + "?", ButtonType.YES, ButtonType.NO);
        alert.showAndWait().ifPresent(r -> {
            if (r == ButtonType.YES) {
                try {
                    proveedorService.delete(p.getIdProveedor());
                    listarProveedores();
                    lblMensaje.setText("Proveedor eliminado.");
                    lblMensaje.setStyle("-fx-text-fill: black;");
                } catch (Exception e) {
                    lblMensaje.setText("No se puede eliminar (posiblemente tiene compras asociadas).");
                    lblMensaje.setStyle("-fx-text-fill: red;");
                }
            }
        });
    }

    @FXML
    private void limpiarFormulario() {
        idEditando = null;
        txtRuc.clear();
        txtRazonSocial.clear();
        txtTelefono.clear();
        txtDireccion.clear();
        btnGuardar.setText("Guardar");
        lblMensaje.setText("");
    }
}