package pe.edu.upeu.conceptos_poo.minimarket.Controladores;

import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.minimarket.dto.ComboBoxOption;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Compra;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.DetalleCompra;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Producto;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Proveedor;
import pe.edu.upeu.conceptos_poo.minimarket.repository.IProveedorRepository;
import pe.edu.upeu.conceptos_poo.minimarket.service.CompraService;
import pe.edu.upeu.conceptos_poo.minimarket.service.ProductoIService;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class RegistroCompraController {

    @FXML private ComboBox<ComboBoxOption> cbProveedor;
    @FXML private ComboBox<String> cbTipoDoc;
    @FXML private TextField txtNumDoc;
    @FXML private TextField txtBuscarProducto;
    @FXML private TableView<DetalleCompra> tablaDetalle;
    @FXML private TableColumn<DetalleCompra, String> colProducto;
    @FXML private TableColumn<DetalleCompra, Integer> colCantidad;
    @FXML private TableColumn<DetalleCompra, Double> colCosto;
    @FXML private TableColumn<DetalleCompra, Double> colSubtotal;
    @FXML private TableColumn<DetalleCompra, Void> colAccion;
    @FXML private Label lblTotal;

    @Autowired private IProveedorRepository proveedorRepository;
    @Autowired private ProductoIService productoService;
    @Autowired private CompraService compraService;

    private ObservableList<DetalleCompra> listaDetalle = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        cargarProveedores();
        cbTipoDoc.setItems(FXCollections.observableArrayList("FACTURA", "BOLETA", "GUIA"));
        configurarTabla();
        txtBuscarProducto.setOnAction(e -> buscarProducto());
    }

    private void cargarProveedores() {
        List<Proveedor> proveedores = proveedorRepository.findAll();
        List<ComboBoxOption> opciones = proveedores.stream()
                .map(p -> new ComboBoxOption(String.valueOf(p.getIdProveedor()), p.getRazonSocial() + " (" + p.getRucDni() + ")"))
                .collect(Collectors.toList());
        cbProveedor.setItems(FXCollections.observableArrayList(opciones));
    }

    private void configurarTabla() {
        tablaDetalle.setEditable(true);
        colProducto.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getProducto().getNombre()));

        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        colCantidad.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
        colCantidad.setOnEditCommit(e -> {
            e.getRowValue().setCantidad(e.getNewValue());
            recalcularTotal(e.getRowValue());
        });

        colCosto.setCellValueFactory(new PropertyValueFactory<>("precioCompra"));
        colCosto.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        colCosto.setOnEditCommit(e -> {
            e.getRowValue().setPrecioCompra(e.getNewValue());
            recalcularTotal(e.getRowValue());
        });

        colSubtotal.setCellValueFactory(new PropertyValueFactory<>("subtotal"));

        colAccion.setCellFactory(param -> new TableCell<>() {
            private final Button btn = new Button("X");
            {
                btn.setStyle("-fx-background-color: red; -fx-text-fill: white;");
                btn.setOnAction(event -> {
                    listaDetalle.remove(getIndex());
                    actualizarTotalGeneral();
                });
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : btn);
            }
        });

        tablaDetalle.setItems(listaDetalle);
    }

    @FXML
    private void buscarProducto() {
        String termino = txtBuscarProducto.getText();

        // MODIFICACIÓN: Si el campo está vacío, traemos TODOS los productos.
        // Si hay texto, filtramos.
        List<Producto> productos;
        if (termino == null || termino.isEmpty()) {
            productos = productoService.findAllProductos();
        } else {
            productos = productoService.findAllProductos().stream()
                    .filter(p -> p.getNombre().toLowerCase().contains(termino.toLowerCase()))
                    .collect(Collectors.toList());
        }

        if (!productos.isEmpty()) {
            // Si encuentra solo uno, lo agrega directo (flujo rápido)
            if (productos.size() == 1) {
                agregarAlDetalle(productos.get(0));
                txtBuscarProducto.clear();
            } else {
                agregarAlDetalle(productos.get(0));

                if (productos.size() > 1) {
                    new Alert(Alert.AlertType.INFORMATION,
                            "Se encontraron " + productos.size() + " productos. Se agregó el primero: " + productos.get(0).getNombre()
                    ).show();
                }
            }
        } else {
            new Alert(Alert.AlertType.WARNING, "No hay productos registrados con ese nombre.\nVaya a 'Gestionar Productos' para crearlo primero.").show();
        }
    }

    private void agregarAlDetalle(Producto p) {
        // Verificar si ya existe en el detalle
        Optional<DetalleCompra> existente = listaDetalle.stream()
                .filter(d -> d.getProducto().getId_producto().equals(p.getId_producto()))
                .findFirst();

        if (existente.isPresent()) {
            existente.get().setCantidad(existente.get().getCantidad() + 1);
            recalcularTotal(existente.get());
        } else {
            DetalleCompra d = new DetalleCompra();
            d.setProducto(p);
            d.setCantidad(1);
            d.setPrecioCompra(p.getPrecioU() * 0.70); // Estimado de costo (70% del precio venta)
            recalcularTotal(d);
            listaDetalle.add(d);
        }
        actualizarTotalGeneral();
        tablaDetalle.refresh();
    }

    private void recalcularTotal(DetalleCompra d) {
        d.setSubtotal(d.getCantidad() * d.getPrecioCompra());
        tablaDetalle.refresh();
        actualizarTotalGeneral();
    }

    private void actualizarTotalGeneral() {
        double total = listaDetalle.stream().mapToDouble(DetalleCompra::getSubtotal).sum();
        lblTotal.setText(String.format("%.2f", total));
    }

    @FXML
    private void guardarCompra() {
        if (cbProveedor.getValue() == null || listaDetalle.isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Seleccione proveedor y agregue productos").show();
            return;
        }

        try {
            Compra compra = new Compra();
            compra.setProveedor(proveedorRepository.findById(Long.parseLong(cbProveedor.getValue().getKey())).orElse(null));
            compra.setFechaEmision(LocalDateTime.now());
            compra.setTipoDocumento(cbTipoDoc.getValue());
            compra.setNumeroDocumento(txtNumDoc.getText());
            compra.setTotal(Double.parseDouble(lblTotal.getText()));
            compra.setDetalleCompras(new ArrayList<>(listaDetalle));

            compraService.registrarCompra(compra);

            new Alert(Alert.AlertType.INFORMATION, "Compra registrada y stock actualizado").show();
            listaDetalle.clear();
            actualizarTotalGeneral();
            txtNumDoc.clear();
        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Error al guardar: " + e.getMessage()).show();
        }
    }
}