package pe.edu.upeu.conceptos_poo.minimarket.repository;

import org.springframework.stereotype.Repository;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.DetalleVenta;

@Repository
public interface IDetalleVentaRepository extends ICrudGenericoRepository<DetalleVenta, Long> {
}