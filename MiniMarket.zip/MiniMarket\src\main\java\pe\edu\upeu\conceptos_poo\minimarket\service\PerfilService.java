package pe.edu.upeu.conceptos_poo.minimarket.service;

import pe.edu.upeu.conceptos_poo.minimarket.modelos.Perfil;

public interface PerfilService extends CRUD_GenericoSefvice_Interface<Perfil, Long>{
}
