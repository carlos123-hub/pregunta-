package pe.edu.upeu.conceptos_poo.minimarket.components;

import javafx.stage.Stage;


public class StageManager {
    private static Stage primaryStage;

    public static void setPrimaryStage(Stage stage) {
        primaryStage = stage;
    }

    public static Stage getPrimaryStage() {
        return primaryStage;
    }
}

